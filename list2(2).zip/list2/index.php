<!doctype html>
<html lang="en">
<head>

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>To-do list</title>
  <link rel="stylesheet" href="main.css"/>
  
  
</head>


<body>
  <header>
    <h1>Task list</h1>
    <form id="task-form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
      <input type="text" name="new-task-input" id="new-task-input" placeholder="What do you have planned?" />
      <input type="submit" id="new-task-submit" name="new-task-submit" value="Add task" />
    </form>
  </header>

  <main>
    <section class="task-list">
      <h2>Tasks</h2>
      <div id="tasks">
        <?php

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new-task-input'])) {
          $taskText = trim($_POST['new-task-input']);
          if (!empty($taskText)) {
              // Append the new task to the tasks.txt file
              file_put_contents("tasks.txt", $taskText . PHP_EOL, FILE_APPEND);
          }
          // Redirect to the same page to avoid form resubmission on refresh
          header("Location: " . $_SERVER['PHP_SELF']);
          exit;
      }
      





          // PHP code to display existing tasks
          if (file_exists("tasks.txt")) {
            $tasks = file("tasks.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($tasks as $task) {
              echo "<div class='task'><div class='content'>" . htmlspecialchars($task) . "</div></div>";
            }
          }
        ?>

      </div>
	  
	  
    </section>
  </main>

  <script src="main.js"></script>
</body>
</html>
