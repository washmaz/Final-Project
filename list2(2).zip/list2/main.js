// references to html elements
const taskForm = document.getElementById("task-form");
const taskInput = document.getElementById("new-task-input");
const taskList = document.getElementById("tasks");

// Event listener to add a new task
taskForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const taskText = taskInput.value.trim();
    if (taskText !== "") {
        addTask(taskText);
        taskInput.value = "";
    }
});

// function for adding new tasks
function addTask(taskText, dueDate) {
    const task = document.createElement("div");
    task.classList.add("task");
    task.innerHTML = `
        <div class="content">
            <input type="text" class="text" value="${taskText}" readonly />
        </div>
        <div class="actions">
            <button class="edit">Edit</button>
            <button class="delete">Delete</button>
            <button class="priority">Priority</button>
            <button class="complete">Complete</button>
        </div>
    `;

    // due date 
    const dueDateInput = document.createElement("input");
    dueDateInput.type = "date";
    dueDateInput.classList.add("due-date");

    if (dueDate) {
        dueDateInput.value = dueDate;
    }

    task.querySelector(".content").appendChild(dueDateInput);

    // edit, delete, priority, and complete buttons
    const editButton = task.querySelector(".edit");
    const deleteButton = task.querySelector(".delete");
    const priorityButton = task.querySelector(".priority");
    const completeButton = task.querySelector(".complete");

    editButton.addEventListener("click", () => {
        editTask(task);
    });

    deleteButton.addEventListener("click", () => {
        deleteTask(task);
    });

    priorityButton.addEventListener("click", () => {
        prioritizeTask(task);
    });

    completeButton.addEventListener("click", () => {
        completeTask(task);
    });

    // Append the task to the task list
    taskList.appendChild(task);
}

function deleteTask(task) {
    task.remove();
}

function prioritizeTask(task) {
    const taskList = task.parentNode;
    const firstTask = taskList.firstChild;

    if (task.classList.contains("prioritized")) {
        // If the task is already prioritized, remove the class
        task.classList.remove("prioritized");
        // Then move it back to its original position (just after the first task)
        taskList.insertBefore(task, firstTask.nextSibling);
    } else {
        // If the task is not prioritized, add the class
        task.classList.add("prioritized");
        // Then move it to the top of the list
        taskList.insertBefore(task, firstTask);
    }
}

// mark a task as completed
function completeTask(task) {
    task.style.backgroundColor = "lightgreen"; // You can customize the style
}

function editTask(task) {
    const textInput = task.querySelector(".text");
    textInput.removeAttribute("readonly");
    textInput.focus();

    // due date input
    const dueDateInput = task.querySelector(".due-date");
    dueDateInput.removeAttribute("readonly");

    textInput.addEventListener("blur", () => {
        textInput.setAttribute("readonly", true);
    });

    dueDateInput.addEventListener("blur", () => {
        dueDateInput.setAttribute("readonly", true);
    });
}

